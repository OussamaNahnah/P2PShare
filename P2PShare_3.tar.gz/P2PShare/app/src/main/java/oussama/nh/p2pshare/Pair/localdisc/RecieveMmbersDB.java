package oussama.nh.p2pshare.Pair.localdisc;

import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;

public class RecieveMmbersDB implements Runnable{
    SqliteHelper sqliteHelper;
    Pair pair;

    public RecieveMmbersDB(SqliteHelper sqliteHelper, Pair pair) {
        this.sqliteHelper = sqliteHelper;
        this.pair = pair;
    }

    @Override
    public void run() {
        try {
            Log.i("rMmbersDb","creceive shared ");
            //******************principal**********************
            MulticastSocket socket = null;
            socket = new MulticastSocket(9969);
            Log.i("rMmbersDb",",, ");
            InetAddress group = InetAddress.getByName("224.0.0.7");
            Log.i("rMmbersDb",",,, ");
            socket.joinGroup(group);
            DatagramPacket packet;
            Log.i("rMmbersDb",",,p ");
            byte[] buf = new byte[2024];
            ObjectInputStream iStream;
            packet = new DatagramPacket(buf, buf.length);

            while(true)
            { Log.i("rMmbersDb",",,pp ");
                socket.receive(packet);
                Log.i("rMmbersDb",",,ppp ");
                iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                Log.i("rMmbersDb",",,pppt ");
                ArrayList<MembersObj> membersObjs = ( ArrayList< MembersObj >) iStream.readObject();
                Log.i("rMmbersDb","count: " + membersObjs.size());
               ///////////////
                 sqliteHelper.delete_Member();
                for (int i=0;i<membersObjs.size();i++){

                    sqliteHelper.addMember(
                            membersObjs.get(i).getIp(),
                            membersObjs.get(i).getName(),
                            membersObjs.get(i).getActive(),
                            membersObjs.get(i).getLast()
                    );
                }
               // PairLocalDisc.update_recycle();
                Log.i("rMmbersDb","files"  + membersObjs.size());
                /////////////////
                iStream.close();
                socket.leaveGroup(group);
                socket.close();
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
