package oussama.nh.p2pshare.Pair.localdisc;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.shared.MSG;
import oussama.nh.p2pshare.shared.Utils;

public class MessgesLocalAdapter extends RecyclerView.Adapter<MessgesLocalAdapter.ViewHolder>  {

    public  static final int MSG_TYPE_LEFT=0;
    public  static final int MSG_TYPE_RIGHT=1;

    private ArrayList<MSG> msg;

    public MessgesLocalAdapter(ArrayList<MSG> msg){

        this.msg=msg;

    }


    @NonNull
    @Override
    public   ViewHolder  onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        if(i==MSG_TYPE_RIGHT)
        {
            View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chat_item_right,viewGroup,false);
            return new MessgesLocalAdapter.ViewHolder(view);
        }else{
            View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.chat_item_left,viewGroup,false);
            return new MessgesLocalAdapter.ViewHolder(view);
        }

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        MSG msg_ = msg.get(i);

        viewHolder.show_message.setText(msg_.getTxt());
        viewHolder.show_ip.setText(msg_.getIp());


    }
    @Override
    public int getItemCount() {
        return msg.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public TextView show_message;
        public TextView show_ip;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            show_message=itemView.findViewById(R.id.show_message);
            show_ip=itemView.findViewById(R.id.show_ip);

            /*
            profile_image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });*/
        }
    }

    @Override
    public int getItemViewType(int position) {
        if(msg.get(position).getIp().equals(Utils.getIPAddress(true)))
            return MSG_TYPE_RIGHT;
        else
            return MSG_TYPE_LEFT;
    }
}