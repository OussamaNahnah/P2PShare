package oussama.nh.p2pshare.Server.shared;

import android.database.Cursor;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;

public class SendfileSrv implements Runnable{
    File_ file_;
    SqliteHelper sqliteHelper;


    public SendfileSrv(File_ file_, SqliteHelper sqliteHelper) {
        this.file_ = file_;
        this.sqliteHelper = sqliteHelper;
    }



    @Override
    public void run() {
        Log.i("send!flSRv", "x:");
        DatagramSocket socket=null;
        try {
            ByteArrayOutputStream bStream = new ByteArrayOutputStream();
            ObjectOutput oo = new ObjectOutputStream(bStream);
            Log.i("send!flSRv", "x2");
            Cursor res = sqliteHelper.get_Files();
            Log.i("send!flSRv", "x3");
            ArrayList<File_> file_s = new ArrayList<>();
            if (res.getCount() == 0) {
                Log.i("send!flSRv", "count 0");
            } else {
                Log.i("send!flSRv", "count "+res.getCount());
                while (res.moveToNext()) {
                    file_s.add(new File_(res.getString(1), res.getString(2), res.getString(3), res.getString(4), res.getString(5)));
                }
            }
            oo.writeObject(file_s);
            Log.i("send!flSRv", "x4");
            oo.close();
            Log.i("send!flSRv", "x5");

            byte[] serializedMessage = bStream.toByteArray();
            Log.i("send!flSRv", "x6");
            Log.i("send!flSRv", "serializedMessage:" + serializedMessage.length);
           DatagramPacket packet = new DatagramPacket(serializedMessage, serializedMessage.length,
                    InetAddress.getByName("224.0.0.5"), 9986);
            Log.i("send!flSRv", "x7");
            socket =new DatagramSocket();
            socket.send(packet);
            Log.i("send!flSRv", "x8");
            socket.close();
            Log.i("send!flSRv", "x9");
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if (socket!=null)socket.close();
        }
    }
}
