package oussama.nh.p2pshare.Pair.localdisc;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.Pair.shared.PairShared;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.members.MembersAdapter;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.Utils;


public class PairLocalDisc extends Fragment {
    static RecyclerView recyclerView;
    static MembersAdapter membersAdapter;
    static ArrayList<MembersObj> membersObjs;
    static SqliteHelper sqliteHelper;

    public PairLocalDisc() {
        // Required empty public constructor
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_pair_local_disc, container, false);
        Log.i("nahnah", "PairLocalDisc ");
        sqliteHelper = new SqliteHelper(root.getContext());
       /* Thread recievefileDb=new Thread(new RecieveFilesDB(sqliteHelper));
        recievefileDb.start();*/
        membersObjs = new ArrayList<>();
        recyclerView = root.findViewById(R.id.pair_lcl_disc_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        update_recy(root);

        return root;
    }

    public void update_recy(View root) {
        Cursor res = sqliteHelper.get_Members();
        if (res.getCount() == 0) {
            Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
        } else {
            //    Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
            while (res.moveToNext()) {
//                if (res.getString(1)!= Utils.getIPAddress(true))
                membersObjs.add(new MembersObj(res.getString(1),res.getString(2),res.getString(3), res.getString(4)));

            }
        }
        membersAdapter = new MembersAdapter(recyclerView.getContext(), membersObjs);
        membersAdapter.setClickListener(new MembersAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(recyclerView.getContext(), "You clicked " + membersAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(root.getContext(), discActivity.class);
                intent.putExtra("ip_partner", membersAdapter.getItem(position) .getIp());
                startActivity(intent);
            }
        });

        recyclerView.setAdapter(membersAdapter);

    }

    public static void update_recycle() {
        Cursor res = sqliteHelper.get_Members();
        if (res.getCount() == 0) {
            Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
        } else {
            //    Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
            while (res.moveToNext()) {
                membersObjs.add(new MembersObj(res.getString(1),res.getString(2),res.getString(3), res.getString(4)));

            }
        }
        membersAdapter = new MembersAdapter(recyclerView.getContext(), membersObjs);
        recyclerView.setAdapter(membersAdapter);

    }


}