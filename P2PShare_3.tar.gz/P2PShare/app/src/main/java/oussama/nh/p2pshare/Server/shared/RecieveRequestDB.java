package oussama.nh.p2pshare.Server.shared;

import android.database.Cursor;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;

public class RecieveRequestDB implements Runnable{
    SqliteHelper sqliteHelper;

    public RecieveRequestDB(SqliteHelper sqliteHelper) {
        this.sqliteHelper = sqliteHelper;
    }

    @Override
    public void run() {
        while (true) {
            Log.i("recRQT", "wssal");


            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket(3000);
                byte msg1[] = new byte[20];
                DatagramPacket datagramPacket = new DatagramPacket(msg1, msg1.length);

                Log.i("recRQT", "rah yab3ath");
                socket.receive(datagramPacket);
                String string = new String(msg1, StandardCharsets.UTF_8);
                Log.i("recRQT", "wsal:" + string);
                socket.close();
                /////////////////////////////////////////////////
                //************************principal**********************
                Log.i("recRQT", "x:");
                try {
                    socket = new DatagramSocket();
                    ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                    ObjectOutput oo = new ObjectOutputStream(bStream);
                    Log.i("recRQT", "x2");
                    Cursor res = sqliteHelper.get_Files();
                    Log.i("recRQT", "x3");
                    ArrayList<File_> file_s = new ArrayList<>();
                    if (res.getCount() == 0) {
                        Log.i("recRQT", "count 0");
                    } else {
                        Log.i("recRQT", "count +0");
                        while (res.moveToNext()) {
                            Log.i("recRQT", "file :"+res.getString(2));
                            file_s.add(new File_(res.getString(1), res.getString(2), res.getString(3), res.getString(4), res.getString(5)));
                        }
                    }
                    oo.writeObject(file_s);
                    Log.i("recRQT", "x4");
                    oo.close();
                    Log.i("recRQT", "x5");

                    byte[] serializedMessage = bStream.toByteArray();
                    Log.i("recRQT", "x6");
                    Log.i("recRQT", "serializedMessage:" + serializedMessage.length);
                 DatagramPacket   packet = new DatagramPacket(serializedMessage, serializedMessage.length,
                                 InetAddress.getByName("224.0.0.2"), 9996);
                         //    InetAddress.getByName("224.0.0.5"), 9986);
                    Log.i("recRQT", "x7");
                    socket.send(packet);
                    Log.i("recRQT", "x8");
                    socket.close();
                    Log.i("recRQT", "x9");
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }////////////////////////

                // onProgressUpdate();
                Log.i("recRQT", "x:");
                try {
                    socket = new DatagramSocket();
                    ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                    ObjectOutput oo = new ObjectOutputStream(bStream);
                    Log.i("recRQT", "x2");
                    Cursor res = sqliteHelper.get_Members();
                    Log.i("recRQT", "x3");
                    ArrayList<MembersObj> membersObjs = new ArrayList<>();

                    if (res.getCount() == 0) {
                        Log.i("recRQT", "count 0");
                    } else {
                        Log.i("recRQT", "count +0");
                        while (res.moveToNext()) {
                            membersObjs.add(new MembersObj(res.getString(1), res.getString(2), res.getString(3), res.getString(4)));
                            Log.i("udp2", "member"+res.getString(1));
                        }
                    }
                    Log.i("recRQT", "count +0");
                    oo.writeObject(membersObjs);
                    Log.i("recRQT", "x4");
                    oo.close();
                    Log.i("recRQT", "x5");

                    byte[] serializedMessage = bStream.toByteArray();
                    Log.i("recRQT", "x6");
                    Log.i("recRQT", "serializedMessage:" + serializedMessage.length);
                    DatagramPacket packet = new DatagramPacket(serializedMessage, serializedMessage.length,

                            InetAddress.getByName("224.0.0.7"), 9969);
                    Log.i("recRQT", "x7");
                    socket.send(packet);
                    Log.i("recRQT", "x8");
                    socket.close();
                    Log.i("recRQT", "x9");
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (socket != null) {
                    socket.close();
                }
            }

        }

    }
}
