package oussama.nh.p2pshare.Server.shared;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.members.MembersAdapter;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.shared.File_;

public class SrvSharedAdapter extends RecyclerView.Adapter<SrvSharedAdapter.ViewHolder> {

    private List<File_> mData;
    private LayoutInflater mInflater;
    private SrvSharedAdapter.ItemClickListener mClickListener;

    // data is passed into the constructor
    public SrvSharedAdapter(Context context, List<File_> data) {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
    }

    // inflates the row layout from xml when needed
    @Override
    public SrvSharedAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.srv_item_file, parent, false);
        return new SrvSharedAdapter.ViewHolder(view);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(SrvSharedAdapter.ViewHolder holder, int position) {
        File_ file_ = mData.get(position);
        holder.name.setText(file_.getName());
        holder.type.setText(file_.getType());
        holder.size.setText(file_.getSize());
    }

    // total number of rows
    @Override
    public int getItemCount() {
        return mData.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView name;
        TextView type;
        TextView size;

        ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.item_file_name);
            type = itemView.findViewById(R.id.item_file_type);
            size = itemView.findViewById(R.id.item_file_size);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }
    }

    // convenience method for getting data at click position
    public File_ getItem(int id) {
        return mData.get(id);
    }

    // allows clicks events to be caught
    public void setClickListener(SrvSharedAdapter.ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
}