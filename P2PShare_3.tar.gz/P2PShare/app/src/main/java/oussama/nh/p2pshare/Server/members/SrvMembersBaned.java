package oussama.nh.p2pshare.Server.members;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import oussama.nh.p2pshare.R;

public class SrvMembersBaned extends Fragment {
    MembersBanedAdapter membersBanedAdapter;


    public SrvMembersBaned() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_srv_members_baned, container, false);


        // data to populate the RecyclerView with
        ArrayList<MembersObj> membersObjs = new ArrayList<>();
        membersObjs.add(new MembersObj("127.0.0.1","name","active","f"));



        // set up the RecyclerView
        RecyclerView recyclerView = root.findViewById(R.id.srv_members_baned_recylrview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        membersBanedAdapter = new MembersBanedAdapter(getContext(), membersObjs);
        membersBanedAdapter.setClickListener(new MembersBanedAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(getContext(), "You clicked " +
                        membersBanedAdapter.getItem(position) +
                        " on row number " + position, Toast.LENGTH_SHORT).show();

            }
        });
        recyclerView.setAdapter(membersBanedAdapter);
        return root;
    }
}