package oussama.nh.p2pshare;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import oussama.nh.p2pshare.Server.Info.SrvInfo;
import oussama.nh.p2pshare.Server.members.SrvMembers;

public class Infromation extends AppCompatActivity {

    private static TabLayout tabLayout;
    private static ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infromation);

        viewPager = (ViewPager) findViewById(R.id.viewpager);
        setupViewPager(viewPager);

        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
    }
    private void setupViewPager(ViewPager viewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new SrvInfo(), "Login");
        adapter.addFragment(new SrvMembers(), "SignUp");

        viewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();

        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    // public static ViewPager viewPager; //GLOBAL
    // public static HomePager adapter; //GLOBAL
    //adapter = new HomePager(getSupportFragmentManager(), hometabLayout.getTabCount()); //onCreate section

    public static void _openSIGNIN() // Create this static method
    {
        viewPager.setCurrentItem(0);
    }

    public static void _openSIGNUP() // Create this static method
    {
        viewPager.setCurrentItem(1);
    }


}