package oussama.nh.p2pshare.Server.localdisc;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;
import oussama.nh.p2pshare.shared.MSG;

public class SendLocalMsgSrv implements Runnable {
    SqliteHelper sqliteHelper;
   MSG msg;
   int port;
   String to;

    public SendLocalMsgSrv(String to,SqliteHelper sqliteHelper, MSG msg, int port) {
        this.sqliteHelper = sqliteHelper;
        this.msg = msg;
        this.port = port;
        this.to = to;
    }

    @Override
    public void run() {
            Log.i("sendlovlmsgsrv","a");
        DatagramSocket socket=null;
            try {
                  socket = new DatagramSocket();
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                ObjectOutput oo = new ObjectOutputStream(bStream);
                Log.i("sendlovlmsgsrv","b");
                oo.writeObject(msg);
                Log.i("sendlovlmsgsrv","c");

                Log.i("sendlovlmsgsrv","d too: "+to);
                byte[] serializedMessage = bStream.toByteArray();
                Log.i("sendlovlmsgsrv","e");
                DatagramPacket send_= new DatagramPacket(serializedMessage, serializedMessage.length, InetAddress.getByName(to), port);
                Log.i("sendlovlmsgsrv","f");
                socket.send(send_);
                Log.i("sendlovlmsgsrv","h");
                bStream.close();
                oo.close();
                socket.close();
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (socket!=null)socket.close();
            }
    }
}