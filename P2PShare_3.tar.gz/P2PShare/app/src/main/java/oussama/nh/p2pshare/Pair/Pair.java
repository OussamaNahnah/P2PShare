package oussama.nh.p2pshare.Pair;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.database.Cursor;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import oussama.nh.p2pshare.Pair.globaldisc.PairGlobalDisc;
import oussama.nh.p2pshare.Pair.globaldisc.RecieveMsgPair;
import oussama.nh.p2pshare.Pair.localdisc.PairLocalDisc;
import oussama.nh.p2pshare.Pair.localdisc.RecieveLocalMsgPair;
import oussama.nh.p2pshare.Pair.localdisc.RecieveMmbersDB;
import oussama.nh.p2pshare.Pair.localdisc.UploadPair;
import oussama.nh.p2pshare.Pair.shared.PairShared;
import oussama.nh.p2pshare.Pair.shared.RecieveFilesDB;
import oussama.nh.p2pshare.Pair.shared.RecieveFilesDBOFFLINE;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.Server.shared.Uploadsrv;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.File_;

public class Pair extends AppCompatActivity {

static  SqliteHelper sqliteHelper;
public static String ip_server;
private static TabLayout tabLayout;
private static ViewPager viewPager;
private static ViewPagerAdapter adapter;
public static ProgressBar progressBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pair);

        sqliteHelper=new SqliteHelper(this);
        Log.i("recmsgp",",,kp ");
        Thread recieveMsgPair=new Thread(new RecieveMsgPair(sqliteHelper,Pair.this,9985));
        recieveMsgPair.start();
        Log.i("rcloclMsg", "s111");
        Thread send=new Thread(new RecieveLocalMsgPair(sqliteHelper,Pair.this,9199));
        send.start();
        Log.i("up1srv", "*");
        Thread SendFILEforreal=new Thread(new UploadPair(Pair.this,9119));
        SendFILEforreal.start();
       /* Log.i("rcloclMsg", "s111");
        Thread down=new Thread(new DownloadPair(Pair.this,9199));
        send.start();*/

        viewPager = (ViewPager) findViewById(R.id.viewpager_pair);
        tabLayout = (TabLayout) findViewById(R.id.tabs_pair);
          adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new PairShared(), "shared");
        adapter.addFragment(new PairLocalDisc(), "local dis");
        adapter.addFragment(new PairGlobalDisc(), "global dis");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);




progressBar=findViewById(R.id.progressBar);
        progressBar.setBackgroundColor(Color.BLACK);



        Cursor cursorServer=sqliteHelper.get_Server();
        if (cursorServer.getCount()!=0){
            if (cursorServer.moveToFirst()){
               ip_server=cursorServer.getString(1);

            }}else {
            Toast.makeText(getApplicationContext(),"Problem there is no Server",Toast.LENGTH_SHORT).show();
        }
     /*   BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_navigation_pair);
        openFragment(new PairShared(),R.id.main_container_pair);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                switch (menuItem.getItemId()) {
                    case R.id.pair_database:
                        openFragment(new PairShared(),R.id.main_container_pair);
                        break;
                    case R.id.pair_localdisc:
                        openFragment(new PairLocalDisc(),R.id.main_container_pair);
                        break;
                    case R.id.pair_globaldisc:
                        openFragment(new PairGlobalDisc(),R.id.main_container_pair);
                        break;

                }
                return true;
            }
        });*/

      /*  RecieveDatabase recieveDatabase=new RecieveDatabase(Pair.this);
        recieveDatabase.execute();*/
        Log.i("rMmbersDb","creceive members 88 -_- ");

        Thread recieveMmbersDB=new Thread(new RecieveMmbersDB(sqliteHelper,this));
        recieveMmbersDB.start();
        Log.i("shared","creceive files 88 -_- ");

        Thread recieve_files_db=new Thread(new RecieveFilesDB(sqliteHelper,this));
        recieve_files_db.start();
        Thread recieve_files_=new Thread(new RecieveFilesDBOFFLINE(sqliteHelper,this));
        recieve_files_.start();

        Log.i("rfiles1", "request");
       /*RecieveFiles recieveFiles=new RecieveFiles(Pair.this);
       recieveFiles.execute();*/

//        try {
//            Thread.sleep(1000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        Log.i("Rqt", "request");
        /*SendRequestDatabase sendRequestDatabase=new SendRequestDatabase(Pair.this);
        sendRequestDatabase.execute(ip_server);*/
        Thread sendRequestDb=new Thread(new SendRequestDb(ip_server));
        sendRequestDb.start();
    }






    @Override
    public void onBackPressed() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(Pair.this);
        builder.setTitle("Exit");
        builder.setMessage("do u wonna to exit");
        builder.setPositiveButton("sure", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                finish();
                System.exit(0);
            }
        });
        builder.setNegativeButton("Not now!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
        //  super.onBackPressed();

    }
    void openFragment(Fragment fragment, int id){
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(id, fragment);
        transaction.addToBackStack("oussama");
        transaction.commit();
    }

    private static class SendRequestDatabase extends AsyncTask<Object, Object, Object> {

        private WeakReference<Pair> activityWeakReference;

        SendRequestDatabase(Pair activity) {
            activityWeakReference = new WeakReference<Pair>(activity);
        }

        @Override
        protected String doInBackground(Object... objects) {
            Log.i("Rqt", "request");
           String ip_server=(String) objects[0];
            DatagramPacket send_;
            DatagramSocket socket = null;
            Log.i("Rqt", "ab3athli db yar7am book");
            Log.i("Rqt", "haho ip server "+ip_server);
                try {
                    String string = "db";
                    byte msg1[] = string.getBytes(StandardCharsets.UTF_8);
                    socket = new DatagramSocket();
                    Log.i("Rqt", "haw rah yab3ath");
                    send_ = new DatagramPacket(msg1, msg1.length, InetAddress.getByName(ip_server), 3000);

                    socket.send(send_);
                    Log.i("Rqt", "b3athdeja");
                } catch (UnknownHostException | SocketException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (socket != null) {
                        socket.close();
                    }
                }



           return null;
        }
    }
    private static class RecieveDatabase extends AsyncTask<Object, Object, Object> {

        private WeakReference<Pair> activityWeakReference;

        RecieveDatabase(Pair activity) {
            activityWeakReference = new WeakReference<Pair>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            Log.i("oussama", "recieve db");
            try {
                //******************principal**********************
                MulticastSocket socket = null;
                socket = new MulticastSocket(9999);
                InetAddress group = InetAddress.getByName("224.0.0.1");
                socket.joinGroup(group);
                DatagramPacket packet;
                byte[] buf = new byte[2048];
                ObjectInputStream iStream;
                packet = new DatagramPacket(buf, buf.length);

                while(true)
                {
                    socket.receive(packet);
                    iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                    ArrayList<MembersObj> res = (ArrayList<MembersObj>) iStream.readObject();


                    Log.i("udp2","count: " + res.size());
                    onProgressUpdate(res);
                    iStream.close();
                    socket.leaveGroup(group);
                    socket.close();
                }

//***************************************************
// ******************principal**********************
             /*   MulticastSocket socket = null;
                socket = new MulticastSocket(9999);

            InetAddress group = InetAddress.getByName("224.0.0.1");
            socket.joinGroup(group);

            DatagramPacket packet;

            byte[] buf = new byte[256];
               byte  b = 'x'; //just a separator for time being
              Arrays.fill(buf,b);
            packet = new DatagramPacket(buf, buf.length);
            String received= "";
            while(received!=null)
            {
                socket.receive(packet);
                received = new String(packet.getData());
                   received = received.substring(0,received.indexOf('x'));
                System.out.println("Address: " + received);
                Log.i("udp","Address: " + received);
            }

            socket.leaveGroup(group);
            socket.close();*/
//***************************************************
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Object... values) {
            super.onProgressUpdate(values);
            Pair activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            ArrayList<MembersObj> membersObjs= (ArrayList<MembersObj>) values[0];
            for (int i=0;i<membersObjs.size();i++){
                activity.sqliteHelper.delete_Member();
                Log.i("udp2","memb: " + membersObjs.get(i).getIp());

                activity.sqliteHelper.addMember(
                        membersObjs.get(i).getIp(),"name",
                        membersObjs.get(i).getActive(),
                        ""
                );
            }
            Log.i("udp2","wwwwwwwwwwwwwwwwwwwww: " + membersObjs.size());

        }
    }
    private static class RecieveFiles extends AsyncTask<Object, Object, Object> {

        private WeakReference<Pair> activityWeakReference;

        RecieveFiles(Pair activity) {
            activityWeakReference = new WeakReference<Pair>(activity);
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            try {
                Log.i("rfiles1","creceive shared ");
                //******************principal**********************
                MulticastSocket socket = null;
                socket = new MulticastSocket(9980); Log.i("shared",",, ");
                InetAddress group = InetAddress.getByName("224.0.0.1");
                Log.i("rfiles1",",,, ");
                socket.joinGroup(group);
                DatagramPacket packet;
                Log.i("rfiles1",",,p ");
                byte[] buf = new byte[256];
                ObjectInputStream iStream;
                packet = new DatagramPacket(buf, buf.length);

                while(true)
                { Log.i("rfiles1",",,pp ");
                    socket.receive(packet);
                    Log.i("rfiles1",",,ppp ");
                    iStream = new ObjectInputStream(new ByteArrayInputStream(buf));
                    ArrayList<File_> res = (ArrayList<File_>) iStream.readObject();


                    Log.i("rfiles1","count: " + res.size());
                    onProgressUpdate(res);
                    iStream.close();
                    socket.leaveGroup(group);
                    socket.close();
                }

//***************************************************
// ******************principal**********************
             /*   MulticastSocket socket = null;
                socket = new MulticastSocket(9999);

            InetAddress group = InetAddress.getByName("224.0.0.1");
            socket.joinGroup(group);

            DatagramPacket packet;

            byte[] buf = new byte[256];
               byte  b = 'x'; //just a separator for time being
              Arrays.fill(buf,b);
            packet = new DatagramPacket(buf, buf.length);
            String received= "";
            while(received!=null)
            {
                socket.receive(packet);
                received = new String(packet.getData());
                   received = received.substring(0,received.indexOf('x'));
                System.out.println("Address: " + received);
                Log.i("udp","Address: " + received);
            }

            socket.leaveGroup(group);
            socket.close();*/
//***************************************************
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Object... values) {
            super.onProgressUpdate(values);
            Pair activity = activityWeakReference.get();
            if (activity == null || activity.isFinishing()) {
                return;
            }
            ArrayList<File_> fileS= (ArrayList<File_>) values[0];
            for (int i=0;i<fileS.size();i++){
                activity.sqliteHelper.delete_Files();
                activity.sqliteHelper.addFile(
                        fileS.get(i).getOwner()
                        ,fileS.get(i).getName()
                        ,fileS.get(i).getPath()
                        ,fileS.get(i).getType()
                        ,fileS.get(i).getSize()
                );
            }
            Log.i("shared","files"  + fileS.size());
           // Toast.makeText(activity.getApplicationContext(),""+fileS.size(),Toast.LENGTH_SHORT).show();

        }
    }
    public static class SendFileAdd extends AsyncTask<Object, Object, Object> {
        private WeakReference<Pair> activityWeakReference;
        public SendFileAdd(Pair activity) {
            activityWeakReference = new WeakReference<Pair>(activity);
        }
        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(Object... objects) {
            Log.i("shared","^:");

           /* File_ file_=(File_) objects[0];
            Log.i("shared","^:^");
            String ip_server=(String) objects[1];
            Log.i("shared","^:^^");
            try {
                DatagramSocket  socket = new DatagramSocket();
                ByteArrayOutputStream bStream = new ByteArrayOutputStream();
                ObjectOutput oo = new ObjectOutputStream(bStream); Log.i("shared","^:^^^");
                oo.writeObject(file_);
                oo.close(); Log.i("shared","^:^^^^^^^");
                byte[] serializedMessage = bStream.toByteArray();
                DatagramPacket send_= new DatagramPacket(serializedMessage, serializedMessage.length, InetAddress.getByName(ip_server), 9998);
                Log.i("shared","^:ù");
                socket.send(send_);
                socket.close();
            } catch (SocketException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }*/


            return null;
        }

    }



    @Override
    protected void onStop() {
        Log.i("stp", "app stoped1");
        super.onStop();
        Log.i("stp", "app stoped2");
    }



    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();

        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    // public static ViewPager viewPager; //GLOBAL
    // public static HomePager adapter; //GLOBAL
    //adapter = new HomePager(getSupportFragmentManager(), hometabLayout.getTabCount()); //onCreate section

    public static void _openSIGNIN() // Create this static method
    {
        viewPager.setCurrentItem(0);
    }

    public static void _openSIGNUP() // Create this static method
    {
        viewPager.setCurrentItem(1);
    }
public static void updatetablayout(){
    viewPager.setAdapter(adapter);
    tabLayout.setupWithViewPager(viewPager);
}public static void updatetablayout_globaldis(){
    viewPager.setAdapter(adapter);
    tabLayout.setupWithViewPager(viewPager);
        viewPager.setCurrentItem(2);
}
/*
public notify(Activity activity){

    NotificationManager mNotificationManager;

    NotificationCompat.Builder mBuilder =
            new NotificationCompat.Builder(viewPager.getContext().getApplicationContext(), "notify_001");
    Intent ii = new Intent(viewPager.getContext().getApplicationContext(), Pair.class);
    PendingIntent pendingIntent = PendingIntent.getActivity(viewPager.getContext(), 0, ii, 0);

    NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
    bigText.bigText("verseurl");
    bigText.setBigContentTitle("Today's Bible Verse");
    bigText.setSummaryText("Text in detail");

    mBuilder.setContentIntent(pendingIntent);
    mBuilder.setSmallIcon(R.mipmap.ic_launcher_round);
    mBuilder.setContentTitle("Your Title");
    mBuilder.setContentText("Your text");
    mBuilder.setPriority(NotificationCompat.PRIORITY_MAX);
    mBuilder.setStyle(bigText);

    mNotificationManager =
            (NotificationManager) viewPager.getContext().getSystemService(viewPager.getContext().NOTIFICATION_SERVICE);

// === Removed some obsoletes
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
    {
        String channelId = "Your_channel_id";
        NotificationChannel channel = new NotificationChannel(
                channelId,
                "Channel human readable title",
                NotificationManager.IMPORTANCE_HIGH);
        mNotificationManager.createNotificationChannel(channel);
        mBuilder.setChannelId(channelId);
    }

    mNotificationManager.notify(0, mBuilder.build());
}*/
}