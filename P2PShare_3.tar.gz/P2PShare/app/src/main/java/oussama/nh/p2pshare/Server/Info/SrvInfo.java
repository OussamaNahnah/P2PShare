package oussama.nh.p2pshare.Server.Info;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


import java.util.Random;

import oussama.nh.p2pshare.Pair.Pair;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.Server.members.MembersTablayoutAdapter;
import oussama.nh.p2pshare.Server.members.SrvMembers;
import oussama.nh.p2pshare.Server.members.SrvMembersBaned;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.Utils;

public class SrvInfo extends Fragment {
    TabLayout srv_members_tabLayout;
   // ViewPager srv_members_viewPager;
    TextView srv_ip;
public    static TextView srv_password;
SqliteHelper sqliteHelper;

    public SrvInfo() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root= inflater.inflate(R.layout.fragment_srv_info, container, false);
        Log.i("nahnah","info");
     //   Server.test();

        Toast.makeText(getContext(),"taslah",Toast.LENGTH_SHORT).show();
        sqliteHelper=new SqliteHelper(root.getContext());

        srv_members_tabLayout=root.findViewById(R.id.srv_members_tabLayout);
//        srv_members_viewPager=root.findViewById(R.id.srv_members_viewPager);
        srv_ip=root.findViewById(R.id.srv_ip_info);
        srv_password=root.findViewById(R.id.srv_password_info);
        srv_ip.setText(Utils.getIPAddress(true));
       // int temp= Server.getPort()+2000;
        srv_password.setText("2000-2005");

   //***************************************************************************************
            FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
            transaction.replace(R.id.srv_members_viewPager, new SrvMembers());
           // transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_right);
            // transaction.addToBackStack(null);
            transaction.commit();
        //***************************************************************************************
       // srv_password.setText(""+randomInt());

      srv_members_tabLayout.addTab(srv_members_tabLayout.newTab().setText("members"));
        srv_members_tabLayout.addTab(srv_members_tabLayout.newTab().setText("baned"));
        srv_members_tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

         MembersTablayoutAdapter adapter = new MembersTablayoutAdapter(getContext(),getActivity().getSupportFragmentManager(), srv_members_tabLayout.getTabCount());
      //  srv_members_viewPager.setAdapter(adapter);

        //srv_members_viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(srv_members_tabLayout));
        srv_members_tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                //srv_members_viewPager.setCurrentItem(tab.getPosition());
                if (tab.getText()=="members"){
                    FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.srv_members_viewPager, new SrvMembers());
                    // transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_right);
                    // transaction.addToBackStack(null);
                    transaction.commit();
                }else {
                    FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
                    transaction.replace(R.id.srv_members_viewPager, new SrvMembersBaned());
                    // transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right, R.anim.enter_from_right, R.anim.exit_to_right);
                    // transaction.addToBackStack(null);
                    transaction.commit();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        }); /*
*/





        return root;
    }

     int randomInt(){
    final int min = 1000;
    final int max = 9999;
    final int random = new Random().nextInt((max - min) + 1) + min;
    return random;

}}