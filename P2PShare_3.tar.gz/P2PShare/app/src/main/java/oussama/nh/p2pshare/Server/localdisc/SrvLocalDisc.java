package oussama.nh.p2pshare.Server.localdisc;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;

import oussama.nh.p2pshare.Pair.localdisc.discActivity;
import oussama.nh.p2pshare.R;
import oussama.nh.p2pshare.Server.Server;
import oussama.nh.p2pshare.Server.members.MembersAdapter;
import oussama.nh.p2pshare.Server.members.MembersObj;
import oussama.nh.p2pshare.database.SqliteHelper;
import oussama.nh.p2pshare.shared.Utils;


public class SrvLocalDisc extends Fragment {

    static RecyclerView recyclerView;
    static MembersAdapter membersAdapter;
    static ArrayList<MembersObj> membersObjs;
    static SqliteHelper sqliteHelper;
    public SrvLocalDisc() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.fragment_srv_local_disc, container, false);
//        Server.test();
        Log.i("nahnaZh","PairLocalDisc ");
        sqliteHelper=new SqliteHelper(root.getContext());
       /* Thread recievefileDb=new Thread(new RecieveFilesDB(sqliteHelper));
        recievefileDb.start();*/
        membersObjs  = new ArrayList<>();
        recyclerView =root. findViewById(R.id.srv_lcl_disc_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        update_recy(root);

        return root;
    }
    public  void update_recy(View root){
        Cursor res=sqliteHelper.get_Members();
        if (res.getCount() == 0) {
            Toast.makeText(recyclerView.getContext(), "count =0", Toast.LENGTH_LONG).show();
        } else {
            //    Toast.makeText(recyclerView.getContext(), "kayan", Toast.LENGTH_LONG).show();
            while (res.moveToNext()) {
//                if (res.getString(1)!= Utils.getIPAddress(true))
                membersObjs.add(new MembersObj(res.getString(1),res.getString(2),res.getString(3), res.getString(4)));


            }
        }
        membersAdapter = new MembersAdapter(recyclerView.getContext(), membersObjs);
        membersAdapter.setClickListener(new MembersAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(recyclerView.getContext(), "You clicked " + membersAdapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(root.getContext(), discActivitySrv.class);
                intent.putExtra("ip_partner", membersAdapter.getItem(position) .getIp());
                startActivity(intent);
            }
        });

        recyclerView.setAdapter(membersAdapter);

    }


}