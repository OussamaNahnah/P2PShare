package oussama.nh.p2pshare.Server.members;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class MembersTablayoutAdapter extends FragmentPagerAdapter {

    private Context myContext;
    int totalTabs;

    public MembersTablayoutAdapter(Context context, FragmentManager fm, int totalTabs) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }

    // this is for fragment tabs
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                SrvMembers srvMembers = new SrvMembers();
               // srvMembers.update();
                return srvMembers;
            case 1:
                SrvMembersBaned srvMembersBaned = new SrvMembersBaned();
                return srvMembersBaned;

            default:
                return null;
        }
    }
// this counts total number of tabs
    @Override
    public int getCount() {
        return totalTabs;
    }
}